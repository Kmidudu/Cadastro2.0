$(document).ready(function(){

    $('#idTable').dataTable();

});