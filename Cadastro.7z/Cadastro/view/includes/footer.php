      
    <!-- fechando a div do container que foi aberto no Header -->
    </div>   
       <div class = "footer text-center text-light fixed-bottom">
          <p>Direitos Reservados</p>
       </div>
  </body>
</html>