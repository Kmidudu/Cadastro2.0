<?php   
   include_once './model/Conexao.class.php';
   include_once './model/Entity.class.php';
   include_once 'header.php';
   include_once 'footer.php';

   $vagaEntity = new Entity();
?>

<div class="container">
  <!-- vagas -->
  
 <br> 
  <!-- container -->
</div>