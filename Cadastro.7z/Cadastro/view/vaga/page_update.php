<?php
    include_once 'header.php';
    include_once '../../model/Conexao.class.php';
    include_once '../../model/Entity.class.php';

    $vaga = new Entity();
    $id = $_POST["id"];
?>
<h2 class="text-center text-light">
    Alterar Vaga
</h2>

<form method="post" action="../../controller/vaga/update_vaga.php">
    <div class="form text-light">

        <?php foreach($vaga->getInfo("vaga",$id) as $vagad) { ?>

            <input type="hidden" name="id" value="<?=$id?>" />
            <div class="form-group">
                Título:
                <input type="text" name="titulo" id="titulo" class="form-control" style="width: 40%;"
                  value="<?=$vagad['titulo']?>" required /> 
                <br>
            </div>
            <div class="form-group">
                Descrição:
                <input type="text" name="descricao" id="descricao" class="form-control"
                  value="<?=$vagad['descricao']?>" required /> 
                <br>
            </div>
            <div class="form-group">
                Ativo:
                <div class="radio-item">
                 <input style="background-color: #323edb" type="radio" id="ativo1" name="ativo" value="s" <?php if($vagad['ativo']=="s"){ echo 'checked' ;}?>>
                 <label for="ativo1">Sim</label>
                </div>

                <div class="radio-item">
                 <input style="background-color: #6a2cb1" type="radio" id="ativo2" name="ativo" value="n" <?php if($vagad['ativo']=="n"){ echo 'checked';}?>>
                 <label for="ativo2">Não</label>
                </div>
        </div>
            <div class="form-group">
                Data:
                <?php $data = date_create($vagad['data']); $d = date_format($data,"Y-m-d"); ?>
                <input type="date" name="data" id="data" class="form-control" style="width:40%;" value="<?php echo $d?>" required /> 
                <br>
            </div>         

        <?php } ?> 

        <button class="btn btn-outline-alt btn-lg">
            Alterar
        </button>
        <a href="boardAdm.php" class="btn btn-outline-exc btn-lg">Voltar</a>

    </div>
</form>

<?php
     include_once '../includes/footer.php'; 
?>
