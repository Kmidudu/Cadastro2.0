<?php   
   include_once '../../model/Conexao.class.php';
   include_once '../../model/Entity.class.php';
   include_once 'headerCoor.php';

   $vagaEntity = new Entity();
?>
<h5>Coordenador</h5>
<div class="container mt-5">
  <!-- vagas -->
  <div class="row" align="center" stlye="text-align:justify;">
      <?php foreach($vagaEntity->list("vaga") as $vagad) { ?> 
            <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
              <div class="card">
              <div class="card-header  <?php if($vagad['ativo']=='s'){ echo 'cardBack1';} else{ echo 'cardBack2';} ?>">
                  <h5 style = "padding-top: 13px;" class="card-title">
                    <?php echo $vagad['titulo']; ?>
                  </h5>
                </div>
                <div class="card-body">
                  <p class="card-text">
                  <?php echo $vagad['descricao']; ?><br><br> Disponível em: <?php $dt = date_create($vagad['data']); $d = date_format($dt,"d/m/Y"); echo $d; ?>       
                  </p>        
                </div>
                <div class="card-footer direita">
                  <form action="page_update.php" method="POST">
                    <input type="hidden" name="id" value="<?=$vagad['id']?>">
                    <button class="btn btn-outline-alt espaco">
                      Alterar
                    </button>
                    </form>
                    <form action="../../controller/vaga/delete_vaga.php" method="POST">
                    <input type="hidden" name="id" value="<?=$vagad['id']?>">
                    <button class="btn btn-outline-exc espaco">
                      Excluir
                    </button>
                    </form>
                </div>
              </div>
            </div>   
            <?php } ?>          
  </div>
 <br> 
  <!-- container -->
</div>

<?php
     include_once '../includes/footer.php'; 
?>